﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testcondition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtName.Text != string.Empty)
            {
                string st ="";
                char[] chars = txtName.Text.ToCharArray();  
                int i = 0;
                int Length = txtName.Text.Length-1 ;
                
                while (i <= Length)
                {
                   
                   
                    char c = chars[i];
                
                   c = chars[Length];
                  //  chars[i] = chars[Length];
                  //s  chars[Length] = c;
                    st += c;

                    Length--;
                  //  i++;
                   // st.App = chars[i];
                   
                   
                }
                txtreverseName.Text = st.ToString();
                MessageBox.Show("Reverse " + st);
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblerror.Visible = false;
            if(txtboxNo1.Text == string.Empty || txtboxno2.Text == string.Empty)
            {
                lblerror.Visible = true;
                lblerror.Text = "Please enter value to be swap";
                
                return;
            }
            string no1;
            string no2;

            no1 = txtboxNo1.Text;
            no2 = txtboxno2.Text;

            txtboxNo1.Text = no2;
            txtboxno2.Text = no1;

           // MessageBox.Show("Its swapped");
       }
    }
}
